'use strict';

const assert = require('assert');

class Sensors {
  
  constructor() { 
    this.arrayT = [];
    

    this.arrayS = [];

    this.arraySD = [];
    this.nextIndex2=0;
    this.nextIndexS=0;
   // console.log(arrayType);
    //@TODO
  }

  /** Clear out all data from this object. */
  async clear() {
    
    //@TODO
  }

  /** Subject to field validation as per FN_INFOS.addSensorType,
   *  add sensor-type specified by info to this.  Replace any
   *  earlier information for a sensor-type with the same id.
   *
   *  All user errors must be thrown as an array of objects.
   */
  async addSensorType(info) {
    
    const sensorType = validate('addSensorType', info);
    var flagT=0;
    for(var i=0; i<this.arrayT.length; i++){
      if(this.arrayT[i].id === info.id)
        flagT=1;
    }
    if(flagT===1){
     // console.log("ID exists");
      throw['ID exists'];
    }
    else{
      this.arrayT.push(info);
     // this.arrayT2.push(info);
    }
    //@TODO
  }
  
  /** Subject to field validation as per FN_INFOS.addSensor, add
   *  sensor specified by info to this.  Replace any earlier
   *  information for a sensor with the same id.
   *
   *  All user errors must be thrown as an array of objects.
   */
  async addSensor(info) {
    const sensor = validate('addSensor', info);
    let flagS=0;
    for(let i=0;i<this.arrayT.length;i++){
      if(info.model === this.arrayT[i].id)
        flagS=1;
    }

    if(flagS === 1){
      this.arrayS.push(info);
    }
    else{
      throw['Matching ID does not exists'];
    }
    
    //@TODO
  }

  /** Subject to field validation as per FN_INFOS.addSensorData, add
   *  reading given by info for sensor specified by info.sensorId to
   *  this. Replace any earlier reading having the same timestamp for
   *  the same sensor.
   *
   *  All user errors must be thrown as an array of objects.
   */
  async addSensorData(info) {
    //console.log(info);
    const sensorData = validate('addSensorData', info);
    let flagSD=0;
    for(let i=0;i<this.arrayS.length;i++){
      if(info.sensorId === this.arrayS[i].id)
        flagSD=1;
    }

    if(flagSD === 1){
      this.arraySD.push(info);
    }
    else{
      throw['Matching ID does not exists'];
    }
   // console.log(sensorData);
    //@TODO
  }
  

  /** Subject to validation of search-parameters in info as per
   *  FN_INFOS.findSensorTypes, return all sensor-types which
   *  satisfy search specifications in info.  Note that the
   *  search-specs can filter the results by any of the primitive
   *  properties of sensor types.  
   *
   *  The returned value should be an object containing a data
   *  property which is a list of sensor-types previously added using
   *  addSensorType().  The list should be sorted in ascending order
   *  by id.
   *
   *  The returned object will contain a lastIndex property.  If its
   *  value is non-negative, then that value can be specified as the
   *  index property for the next search.  Note that the index (when 
   *  set to the lastIndex) and count search-spec parameters can be used
   *  in successive calls to allow scrolling through the collection of
   *  all sensor-types which meet some filter criteria.
   *
   *
   *  All user errors must be thrown as an array of objects.
   */
  async findSensorTypes(info) {
    
    const searchSpecs = validate('findSensorTypes', info);
    
    /*
    sort the Array
    */

   this.arrayT.sort((a, b) => (a.id > b.id) ? 1 : -1)
   // this.arrayT.sort(compare);

    /*
    Object to store parameters from info
    */
    let paramT = {
      count: { },
      index: { },
      id: { }, 
      manufacturer: { }, 
      modelNumber: { }, 
      quantity: { }, 
      unit: { },
      limits: { type: 'range', },
    };
    paramT = info;
    //console.log(paramT);
    let retArr1=[];
    let nextIndex;
    //let nextIndex2=0;
    let nextIndex1=-1;

    /*main IF condition*/
    if(paramT.id || paramT.manufacturer || paramT.unit || paramT.quantity || paramT.modelNumber){
    /*For ID*/
        if(paramT.id){
          let flagT=0;
          for(let j of this.arrayT){
            //console.log(j);
            if(j.id === paramT.id){
              retArr1.push(j);
              flagT=1;
            }
          }
          if(flagT===0)
            throw ['unknown sensor id ${paramT.id} '];
        }
        
        /*For manufacturer*/
        if(paramT.manufacturer){
          for(let j of this.arrayT){
            //console.log(j);
            if(j.manufacturer === paramT.manufacturer)
              retArr1.push(j);
          }
        }
        
        /*For quantity*/
        if(paramT.quantity){
          for(let j of this.arrayT){
            //console.log(j);
            if(j.quantity === paramT.quantity)
              retArr1.push(j);
          }
        }
        
        /*For unit*/
        if(paramT.unit){
          for(let j of this.arrayT){
            //console.log(j);
            if(j.unit === paramT.unit)
              retArr1.push(j);
          }
        }
        
        /*For modelNumber*/
        if(paramT.modelNumber){
          for(let j of this.arrayT){
            //console.log(j);
            if(j.modelNumber === paramT.modelNumber)
            retArr1.push(j);
          }
        }
        nextIndex1=-1; 
        nextIndex=nextIndex1;  
    }
    else{
      let countT=DEFAULT_COUNT;
      let indexT=this.nextIndex2;
      //console.log(indexT);
      if(paramT.index){
        indexT = paramT.index;

        //console.log(indexT);
      }
      if(paramT.count){
        countT = paramT.count;
        console.log(countT);
      }
      let TotalCountT = +indexT + +countT;
      //console.log(TotalCountT);
      //console.log(this.arrayT[1].id);
      for(let i=indexT;i<TotalCountT;i++){
          retArr1.push(this.arrayT[i]);
          this.nextIndex2=+i + 1;
      }
     // nextIndex2=retArr1.length;
      nextIndex=this.nextIndex2;
      //console.log("else");
    }
    
    //@TODO
    return {nextIndex,data:retArr1};
  }
  
  /** Subject to validation of search-parameters in info as per
   *  FN_INFOS.findSensors, return all sensors which
   *  satisfy search specifications in info.  Note that the
   *  search-specs can filter the results by any of the primitive
   *  properties of a sensor.  
   *
   *  The returned value should be an object containing a data
   *  property which is a list of all sensors satisfying the
   *  search-spec which were previously added using addSensor().  The
   *  list should be sorted in ascending order by id.
   *
   *  If info specifies a truthy value for a doDetail property, 
   *  then each sensor S returned within the data array will have
   *  an additional S.sensorType property giving the complete 
   *  sensor-type for that sensor S.
   *
   *  The returned object will contain a lastIndex property.  If its
   *  value is non-negative, then that value can be specified as the
   *  index property for the next search.  Note that the index (when 
   *  set to the lastIndex) and count search-spec parameters can be used
   *  in successive calls to allow scrolling through the collection of
   *  all sensors which meet some filter criteria.
   *
   *  All user errors must be thrown as an array of objects.
   */
  async findSensors(info) {
    //console.log(info);
    const searchSpecs = validate('findSensors', info);

    this.arraySD.sort((a, b) => (a.id > b.id) ? 1 : -1);


    /*
    Object to store parameters from info
    */
   let paramS = {
    count: { },
    index: { },
    id: { },
    model: { },
    period: { type: 'integer' },
    expected: { type: 'range' },
    };
    paramS = info;
    //console.log(paramS);
    //console.log(this.arrayS);
    let retArr2=[];
    let nextIndex;
    let nextIndex2=0;
    let nextIndex1=-1;

    /*main IF condition*/
    if(paramS.id || paramS.model || paramS.period){

      let indexT=this.nextIndexS;
      let countT=DEFAULT_COUNT;

      if(paramS.index){
        indexT = paramS.index;

       // console.log(indexT);
      }
      if(paramS.count){
        countT = paramS.count;
       // console.log(countT);
      }

    /*For ID*/
        if(paramS.id){
          let flagS=0;
          for(let j of this.arrayS){
            //console.log(j);
            if(j.id === paramS.id){
              retArr2.push(j);
              flagS=1;
            }
          }
          if(flagS===0)
            throw ['unknown sensor id'];
        }
        
        /*For model*/
        if(paramS.model){
          //console.log("model");
          let countMod=0;
          let indexMod=0;
          let TotalCountT = +indexT + +countT;
         // console.log(TotalCountT);
          for(let j=indexT; j<this.arrayS.length; j++){
            //console.log(j);
            if(this.arrayS[j].model === paramS.model && countMod<countT){
              retArr2.push(this.arrayS[j]);
              countMod++;
              this.nextIndexS=+j +1;
            }
          //indexMod++;
          }
        nextIndex1=this.nextIndexS;
        }
        
        /*For quantity*/
        if(paramS.period){
          for(let j of this.arrayS){
            //console.log(j);
            if(j.period === paramS.period)
              retArr2.push(j);
          }
        }
         
        nextIndex=nextIndex1;  
        //console.log("if");
    }
    else{
     // console.log("else");
      let countT=DEFAULT_COUNT;
      let indexT=this.nextIndexS;
      if(paramS.index){
        indexT = paramS.index;

        //console.log(indexT);
      }
      if(paramS.count){
        countT = paramS.count;
       // console.log(countT);
      }
      let TotalCountT = +indexT + +countT;
      //console.log(TotalCountT);
      //console.log(this.arrayT[1].id);
      for(let i=indexT;i<TotalCountT;i++){
          retArr2.push(this.arrayS[i]);
          this.nextIndexS=+i +1;
      }
      
      nextIndex=this.nextIndexS;
      //console.log("else");
    }
    //@TODO
    return {nextIndex, data:retArr2};
  }
  
  /** Subject to validation of search-parameters in info as per
   *  FN_INFOS.findSensorData, return all sensor reading which satisfy
   *  search specifications in info.  Note that info must specify a
   *  sensorId property giving the id of a previously added sensor
   *  whose readings are desired.  The search-specs can filter the
   *  results by specifying one or more statuses (separated by |).
   *
   *  The returned value should be an object containing a data
   *  property which is a list of objects giving readings for the
   *  sensor satisfying the search-specs.  Each object within data
   *  should contain the following properties:
   * 
   *     timestamp: an integer giving the timestamp of the reading.
   *     value: a number giving the value of the reading.
   *     status: one of "ok", "error" or "outOfRange".
   *
   *  The data objects should be sorted in reverse chronological
   *  order by timestamp (latest reading first).
   *
   *  If the search-specs specify a timestamp property with value T,
   *  then the first returned reading should be the latest one having
   *  timestamp <= T.
   * 
   *  If info specifies a truthy value for a doDetail property, 
   *  then the returned object will have additional 
   *  an additional sensorType giving the sensor-type information
   *  for the sensor and a sensor property giving the sensor
   *  information for the sensor.
   *
   *  Note that the timestamp and count search-spec parameters can be
   *  used in successive calls to allow scrolling through the
   *  collection of all readings for the specified sensor.
   *
   *  All user errors must be thrown as an array of objects.
   */
  async findSensorData(info) {
    const searchSpecs = validate('findSensorData', info);
    
    /*sorting the array according to timestamp*/
    this.arraySD.sort((a, b) => (a.timestamp > b.timestamp) ? -1 : 1);
    

    let expectedSD;
    let modelSD;
    let limitSD;

    /*
    Function for finding the status
    */
    /*function inRange(value,e1,e2,l1,l2){
      //let inVal;
      if(value>l2 || value<l1)
        return -1;
      if((value>l1 && value<e1) || (value>2 && value<l2))
        return 0;
      return 1; 
    }*/

   /* function inRange(value,e1,e2,l1,l2){
      //let inVal;
      if(value>=e1 && value<=e2){
        return 1;
      }
      else if(value>e2){
        if(value>=l1 && value<=l2)
          return 0;
      }
      else{
        return -1;
      }      
    }*/


    for(let j of this.arraySD){
      for(let i=0;i<this.arrayS.length;i++){
        if(j.sensorId === this.arrayS[i].id){
          expectedSD = this.arrayS[i].expected;
          modelSD = this.arrayS[i].model;
        }
      }
      for(let i=0;i<this.arrayT.length;i++){
        if(modelSD === this.arrayT[i].id){
          limitSD = this.arrayT[i].limits;
        }
      }
      //console.log("Expected "+ expectedSD.min + " "+ expectedSD.max);
      //console.log("Limit "+ limitSD.min+ " " + limitSD.max);
      /*let intVal2=inRange(j.value,expectedSD.min,expectedSD.max,limitSD.min,limitSD.max);
      console.log(intVal2);
      if(intVal2===1)
        j.status ='ok';
      else if(intVal2===0)
        j.status ='outOfRange';
      else    
        j.status ='error';
      */
      if(parseFloat(j.value)>=parseFloat(expectedSD.min) && parseFloat(j.value)<=parseFloat(expectedSD.max)){
        j.status ='ok';
      }
      else if((parseFloat(j.value)>parseFloat(expectedSD.max) && parseFloat(j.value)<=parseFloat(limitSD.max)) || (parseFloat(j.value)<parseFloat(expectedSD.min) && parseFloat(j.value)>=parseFloat(limitSD.min))){
        j.status ='outOfRange';
      }
      else{
        j.status ='error';
      }
     // console.log(j.value);
     // console.log(j.status);
      //console.log("\n");
      //console.log(expectedSD);
      //console.log(limitSD);
    }
    //console.log(this.arraySD);
    let retArr3 = [];
    let retType = {};
    let retSen = {};
    let countSD = searchSpecs.count;
    let statusSD;
    let statusSD2;
    let statusSD3;
    let ssD1;
    let ssD2;
    let detailSD = searchSpecs.doDetail;
    let tsMod=99999999999999;
   // console.log(searchSpecs.statuses);
    
    if(searchSpecs.statuses){
      statusSD = searchSpecs.statuses.values();
      statusSD2 = statusSD.next().value;  
      statusSD3 = statusSD.next().value;
    }
    //console.log(statusSD2);
    //console.log(statusSD3);

    if(searchSpecs.sensorId && !statusSD2 && !statusSD3){
      let flagSD=0;
      let countMod=0;
      if(searchSpecs.timestamp){
        tsMod=searchSpecs.timestamp;
      }
      for(let j of this.arraySD){
        //console.log(j);
        if(j.sensorId === searchSpecs.sensorId && countMod<countSD && tsMod>j.timestamp){
          retArr3.push(j);
          flagSD=1;
          countMod++;
        }

      }
      
      /*if(flagSD===0)
        throw ['unknown sensor id'];*/
    }

    else if(searchSpecs.sensorId && statusSD2 && !statusSD3){
      //console.log("2nd if");
      let flagSD=0;
      let countMod=0;
      if(searchSpecs.timestamp){
        tsMod=searchSpecs.timestamp;
      }
      for(let j of this.arraySD){
        //console.log(j);
        if(j.sensorId === searchSpecs.sensorId && countMod<countSD && tsMod>j.timestamp && j.status===statusSD2){
          retArr3.push(j);
          flagSD=1;
          countMod++;
        }

      }
      
      /*if(flagSD===0)
        throw ['unknown sensor id'];*/
    }

    else if(searchSpecs.sensorId && statusSD2 && statusSD3){
      //console.log("3rd if");
      let flagSD=0;
      let countMod=0;
      if(searchSpecs.timestamp){
        tsMod=searchSpecs.timestamp;
      }
      for(let j of this.arraySD){
        //console.log(j);
        if(j.sensorId === searchSpecs.sensorId && countMod<countSD && tsMod>j.timestamp && (j.status===statusSD2
          || j.status===statusSD3)){
          retArr3.push(j);
          flagSD=1;
          countMod++;
        }

      }
      
      /*if(flagSD===0)
        throw ['unknown sensor id '];*/
    }
    
    else{}

    if(detailSD){
      //console.log("HH");
      for(let j of this.arrayS){
        //console.log(j);
        if(j.id === searchSpecs.sensorId){
          retSen=j;
        }
      }
      for(let j of this.arrayT){
        //console.log(j);
        if(j.id === retSen.model){
          retType=j;
        }
      }

    }


    let arrayFinal =[];
    for(let i=0;i<retArr3.length;i++){
      const picked = (({ value, timestamp, status }) => ({ value, timestamp, status }))(retArr3[i]);
      arrayFinal.push(picked);
    }

    //@TODO
    //console.log(this.arraySD);
    return {data:arrayFinal,sensorType:retType,sensor:retSen};  
  }
}

module.exports = Sensors;

//@TODO add auxiliary functions as necessary

const DEFAULT_COUNT = 5;    

/** Validate info parameters for function fn.  If errors are
 *  encountered, then throw array of error messages.  Otherwise return
 *  an object built from info, with type conversions performed and
 *  default values plugged in.  Note that any unknown properties in
 *  info are passed unchanged into the returned object.
 */
function validate(fn, info) {
  const errors = [];
  const values = validateLow(fn, info, errors);
  if (errors.length > 0) throw errors; 
  return values;
}

function validateLow(fn, info, errors, name='') {
  const values = Object.assign({}, info);
  for (const [k, v] of Object.entries(FN_INFOS[fn])) {
    const validator = TYPE_VALIDATORS[v.type] || validateString;
    const xname = name ? `${name}.${k}` : k;
    const value = info[k];
    const isUndef = (
      value === undefined ||
      value === null ||
      String(value).trim() === ''
    );
    values[k] =
      (isUndef)
      ? getDefaultValue(xname, v, errors)
      : validator(xname, value, v, errors);
  }
  return values;
}

function getDefaultValue(name, spec, errors) {
  if (spec.default !== undefined) {
    return spec.default;
  }
  else {
    errors.push(`missing value for ${name}`);
    return;
  }
}

function validateString(name, value, spec, errors) {
  assert(value !== undefined && value !== null && value !== '');
  if (typeof value !== 'string') {
    errors.push(`require type String for ${name} value ${value} ` +
		`instead of type ${typeof value}`);
    return;
  }
  else {
    return value;
  }
}

function validateNumber(name, value, spec, errors) {
  assert(value !== undefined && value !== null && value !== '');
  switch (typeof value) {
  case 'number':
    return value;
  case 'string':
    if (value.match(/^[-+]?\d+(\.\d+)?([eE][-+]?\d+)?$/)) {
      return Number(value);
    }
    else {
      errors.push(`value ${value} for ${name} is not a number`);
      return;
    }
  default:
    errors.push(`require type Number or String for ${name} value ${value} ` +
		`instead of type ${typeof value}`);
  }
}

function validateInteger(name, value, spec, errors) {
  assert(value !== undefined && value !== null && value !== '');
  switch (typeof value) {
  case 'number':
    if (Number.isInteger(value)) {
      return value;
    }
    else {
      errors.push(`value ${value} for ${name} is not an integer`);
      return;
    }
  case 'string':
    if (value.match(/^[-+]?\d+$/)) {
      return Number(value);
    }
    else {
      errors.push(`value ${value} for ${name} is not an integer`);
      return;
    }
  default:
    errors.push(`require type Number or String for ${name} value ${value} ` +
		`instead of type ${typeof value}`);
  }
}

function validateRange(name, value, spec, errors) {
  assert(value !== undefined && value !== null && value !== '');
  if (typeof value !== 'object') {
    errors.push(`require type Object for ${name} value ${value} ` +
		`instead of type ${typeof value}`);
  }
  return validateLow('_range', value, errors, name);
}

const STATUSES = new Set(['ok', 'error', 'outOfRange']);

function validateStatuses(name, value, spec, errors) {
  assert(value !== undefined && value !== null && value !== '');
  if (typeof value !== 'string') {
    errors.push(`require type String for ${name} value ${value} ` +
		`instead of type ${typeof value}`);
  }
  if (value === 'all') return STATUSES;
  const statuses = value.split('|');
  const badStatuses = statuses.filter(s => !STATUSES.has(s));
  if (badStatuses.length > 0) {
    errors.push(`invalid status ${badStatuses} in status ${value}`);
  }
  return new Set(statuses);
}

const TYPE_VALIDATORS = {
  'integer': validateInteger,
  'number': validateNumber,
  'range': validateRange,
  'statuses': validateStatuses,
};


/** Documents the info properties for different commands.
 *  Each property is documented by an object with the
 *  following properties:
 *     type: the type of the property.  Defaults to string.
 *     default: default value for the property.  If not
 *              specified, then the property is required.
 */
const FN_INFOS = {
  addSensorType: {
    id: { }, 
    manufacturer: { }, 
    modelNumber: { }, 
    quantity: { }, 
    unit: { },
    limits: { type: 'range', },
  },
  addSensor:   {
    id: { },
    model: { },
    period: { type: 'integer' },
    expected: { type: 'range' },
  },
  addSensorData: {
    sensorId: { },
    timestamp: { type: 'integer' },
    value: { type: 'number' },
  },
  findSensorTypes: {
    id: { default: null },  //if specified, only matching sensorType returned.
    index: {  //starting index of first result in underlying collection
      type: 'integer',
      default: 0,
    },
    count: {  //max # of results
      type: 'integer',
      default: DEFAULT_COUNT,
    },
  },
  findSensors: {
    id: { default: null }, //if specified, only matching sensor returned.
    index: {  //starting index of first result in underlying collection
      type: 'integer',
      default: 0,
    },
    count: {  //max # of results
      type: 'integer',
      default: DEFAULT_COUNT,
    },
    doDetail: { //if truthy string, then sensorType property also returned
      default: null, 
    },
  },
  findSensorData: {
    sensorId: { },
    timestamp: {
      type: 'integer',
      default: Date.now() + 999999999, //some future date
    },
    count: {  //max # of results
      type: 'integer',
      default: DEFAULT_COUNT,
    },
    statuses: { //ok, error or outOfRange, combined using '|'; returned as Set
      type: 'statuses',
      default: new Set([]),
    },
    doDetail: {     //if truthy string, then sensor and sensorType properties
      default: null,//also returned
    },
  },
  _range: { //pseudo-command; used internally for validating ranges
    min: { type: 'number' },
    max: { type: 'number' },
  },
};  

