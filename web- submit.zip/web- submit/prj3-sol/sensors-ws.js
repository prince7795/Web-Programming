const cors = require('cors');
const express = require('express');
const bodyParser = require('body-parser');

const AppError = require('./app-error');

const OK = 200;
const CREATED = 201;
const BAD_REQUEST = 400;
const NOT_FOUND = 404;
const CONFLICT = 409;
const SERVER_ERROR = 500;

function serve(port, model) {
  //@TODO set up express app, routing and listen
  const app = express();
  app.locals.port = port;
  app.locals.model = model;
  setupRoutes(app);
  app.listen(port, function(){
    console.log(`listening ${port}`);
  });
}

module.exports = { serve };

let type1;
function setupRoutes(app){
  type1 = '/sensor-types';
  const type2 = '/sensors';
  const type3 = '/sensor-data';;
  app.use(cors());
  app.use(bodyParser.json());
  app.get(type1, doList1(app));
  app.get(type2, doList2(app));
  //app.get(type3, doList3(app));
  app.get(`${type1}/:id`, doGet1(app));
  app.get(`${type2}/:id`, doGet2(app));
  //app.get(`${type3}/:id`, doGet3(app));
  app.get(`${type3}/:id`, doparam1(app));
  app.get(`${type3}/:id/:timestamp`,doparam2(app));
  app.post(type1, doCreate1(app));
  app.post(type2, doCreate2(app));
  app.post(`${type3}/:sensorId`, doReplace(app));
}



function doList1(app) {
  return errorWrap(async function(req, res) {
    const q = req.query || {};
    try {
      const results = await app.locals.model.findSensorTypes(q);
      results.self = requestUrl(req);
      var self1 = requestUrl(req).split("?");
      if(q._count && q._index){
        results.next = req.protocol + "://" + req.hostname +":"+req.app.locals.port + `${type1}` + "?_index=" + results.nextIndex + "&_count=" + q._count; 
        results.prev = req.protocol + "://" + req.hostname +":"+req.app.locals.port + `${type1}` + "?_index=" + results.previousIndex + "&_count=" + q._count;
      }
      else{
        if(!q.manufacturer){
          results.next = req.protocol + "://" + req.hostname +":"+req.app.locals.port + `${type1}` + "?_index=" + results.nextIndex ;
        }
      }
      for(let i of results.data){
        i.self = self1[0]+ "/" + i.id;
      }

      res.json(results);


    }
    catch (err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}

function doList2(app) {
  return errorWrap(async function(req, res) {
    const q = req.query || {};
    try {
      const results = await app.locals.model.findSensors(q);
      results.self = requestUrl(req);
        if(results.data.length!==0 && q._count)
          results.next = requestUrl(req) + "&_index=" + q._count; 
        
      
      for(let i of results.data){
        i.self = requestUrl(req) +"/"+ i.id;
      }
      res.json(results);
    }
    catch (err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}


function doGet1(app) {
  return errorWrap(async function(req, res) {
    try {
      const id = req.params.id;
      const results = await app.locals.model.findSensorTypes({ id: id });
      results.self = requestUrl(req);
      for(let i of results.data){
        i.self = requestUrl(req);
      }
      if (results.length === 0) {
	throw {
	  isDomain: true,
	  errorCode: 'NOT_FOUND',
	  message: `user ${id} not found`,
	};
      }
      else {
	res.json(results);
      }
    }
    catch(err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}

function doGet2(app) {
  return errorWrap(async function(req, res) {
    try {
      const id = req.params.id;
      const results = await app.locals.model.findSensors({ id: id });
      results.self = requestUrl(req);
      for(let i of results.data){
        i.self = requestUrl(req);
      }
      if (results.length === 0) {
	throw {
	  isDomain: true,
	  errorCode: 'NOT_FOUND',
	  message: `user ${id} not found`,
	};
      }
      else {
	res.json(results);
      }
    }
    catch(err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}

function doparam1(app) {
  return errorWrap(async function(req, res) {
    try {
      const id = req.params.id;
      const time = req.query.timestamp;
      const status = req.query.statuses;
      const results = await app.locals.model.findSensorData({ sensorId: id , timestamp:time, statuses:status});
      results.self = requestUrl(req);
      let self1 = requestUrl(req).split("?");
      for(let i of results.data){
        i.self = self1[0] +"/"+ i.timestamp;
      }

      if (results.length === 0) {
	throw {
	  isDomain: true,
	  errorCode: 'NOT_FOUND',
	  message: `user ${id} not found`,
	};
      }
      else {
	res.json(results);
      }
    }
    catch(err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}

function doparam2(app) {
  return errorWrap(async function(req, res) {
    try {
      const id = req.params.id;
      const id2 = req.params.timestamp;
      //const time = req.query.timestamp;
      //const status = req.query.statuses;
      const results = await app.locals.model.findSensorData({ sensorId: id , timestamp:id2});
      // results.data.filter(function(){
      //   timestamp = id2;
      // });
      
      var dataArr = [];
      for (let i of results.data){
        if(i.timestamp == id2)
          dataArr.push(i);
          i.self = requestUrl(req);
      }

      
      if (dataArr.length === 0) {
	throw {
	  isDomain: true,
	  errorCode: 'NOT_FOUND',
	  message: `no data for timestamp ${id2} `,
	};
      }
      else {
	      res.json({data:dataArr,self:requestUrl(req),nextIndex:-1});
      }
    }
    catch(err) {
      const mapped = mapError(err);
      //console.log(mapped);
      const mapped2=Object.assign({}, mapped);
      //console.log(mapped2);
      delete mapped2.status;
      const mapped3={errors:[mapped2]};
      //console.log(mapped3);
      res.status(mapped.status).json(mapped3);
     // res.status(mapped.status).json(mapped);
    }
  });
}

function doCreate1(app) {
  return errorWrap(async function(req, res) {
    try {
      const obj = req.body;
      const results = await app.locals.model.addSensorType(obj);
      res.append('Location', requestUrl(req) + '/' + obj.id);
      res.sendStatus(CREATED);
    }
    catch(err) {
      const mapped = mapError(err);
      res.status(mapped.status).json(mapped);
    }
  });
}

function doCreate2(app) {
  return errorWrap(async function(req, res) {
    try {
      const obj = req.body;
      const results = await app.locals.model.addSensor(obj);
      res.append('Location', requestUrl(req) + '/' + obj.id);
      res.sendStatus(CREATED);
    }
    catch(err) {
      const mapped = mapError(err);
      res.status(mapped.status).json(mapped);
    }
  });
}

function doReplace(app) {
  return errorWrap(async function(req, res) {
    try {
      const replacement = Object.assign({}, req.body);
      replacement.sensorId = req.params.sensorId;
      const results = await app.locals.model.addSensorData(replacement);
      res.sendStatus(CREATED);
    }
    catch(err) {
      const mapped = mapError(err);
      res.status(mapped.status).json(mapped);
    }
  });
}


//@TODO routing function, handlers, utility functions









/** Set up error handling for handler by wrapping it in a 
 *  try-catch with chaining to error handler on error.
 */
function errorWrap(handler) {
  return async (req, res, next) => {
    try {
      await handler(req, res, next);
    }
    catch (err) {
      next(err);
    }
  };
}

/*************************** Mapping Errors ****************************/

const ERROR_MAP = {
  EXISTS: CONFLICT,
  NOT_FOUND: NOT_FOUND
}

/** Map domain/internal errors into suitable HTTP errors.  Return'd
 *  object will have a "status" property corresponding to HTTP status
 *  code.
 */
function mapError(err) {
  console.error(err);
  return err.isDomain
    ? { status: (ERROR_MAP[err.errorCode] || BAD_REQUEST),
	code: err.errorCode,
	message: err.message
      }
    : { status: NOT_FOUND,
	code: 'NOT_FOUND',
	message: err.toString()
      };
} 

/****************************** Utilities ******************************/

/** Return original URL for req */
function requestUrl(req) {
  const port = req.app.locals.port;
  return `${req.protocol}://${req.hostname}:${port}${req.originalUrl}`;
}
