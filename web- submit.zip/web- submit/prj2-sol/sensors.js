'use strict';

const AppError = require('./app-error');
const validate = require('./validate');

const assert = require('assert');
const mongo = require('mongodb').MongoClient;


class Sensors {

  constructor(client,db){
    this.client = client;
    this.db = client.db(db);
    //this.COL = this.db.collection("COL");
    for( const [k,v] of Object.entries(COLLECTIONS)){
      this[k] = this.db.collection(v);
    }
  }


  /** Return a new instance of this class with database as
   *  per mongoDbUrl.  Note that mongoDbUrl is expected to
   *  be of the form mongodb://HOST:PORT/DB.
   */
  static async newSensors(mongoDbUrl) {

    ////URL checking/////
    /////////////////////
    function validURL(mongoDbUrl) {
      let pattern = new RegExp("^(mongodb)\://[a-z\.]+\.[a-zA-Z]{2,3}(:[0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&amp;%\$#\=~])*$");
      return !!pattern.test(mongoDbUrl);
    }

    // validURL(mongoDbUrl);

    if(validURL(mongoDbUrl)){
    
    ///URL Validation////////
    //////////////////
    var URL2 = mongoDbUrl;
    //console.log(URL2);
    let URLArr = URL2.split("//");
    //console.log(URLArr[0]);
    let URLArr2 = URLArr[1].split('/');

    //console.log(URLArr2[0]);
    let db = URLArr2[1];

    let URL = URLArr[0] +"//"+ URLArr2[0];

    //console.log(URL);
    //console.log(db);

    ///URl Validation ends here/////////
    ////////////////////////////////////
    
    const client = await mongo.connect(URL,{useNewUrlParser: true, useUnifiedTopology: true});
    return new Sensors(client,db);  
    }

    else{
      const err = 'URL is not correct';
      throw [new AppError('x_ID',err)];
    }
    //const db = client.db(DBName);
   // console.log("DB connected");
    //constuctor(client,db);
    //   
  }

  /** Release all resources held by this Sensors instance.
   *  Specifically, close any database connections.
   */
  async close() {
    //@TODO
    await this.client.close();
  }

  /** Clear database */
  async clear() {
    //@TODO
    await this.db.collection("sensorType").deleteMany({});
    await this.db.collection("sensor").deleteMany({});
    await this.db.collection("sensorData").deleteMany({});
    
  }

  /** Subject to field validation as per validate('addSensorType',
   *  info), add sensor-type specified by info to this.  Replace any
   *  earlier information for a sensor-type with the same id.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async addSensorType(info) {
    const sensorType = validate('addSensorType', info);
    //console.log(sensorType);
  
    await this.db.collection("sensorType").replaceOne({id : sensorType.id},
    sensorType,{upsert: true});
    //await this.db.collection("sensorType").insertOne(sensorType);
    //@TODO
  }
  
  /** Subject to field validation as per validate('addSensor', info)
   *  add sensor specified by info to this.  Note that info.model must
   *  specify the id of an existing sensor-type.  Replace any earlier
   *  information for a sensor with the same id.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async addSensor(info) {
    const sensor = validate('addSensor', info);
    let flag2=0;
    let ret = await this.db.collection("sensorType").find().toArray();
    for(let i of ret){
      if(i.id === sensor.model){
        await this.db.collection("sensor").replaceOne({id : sensor.id},
          sensor,{upsert: true});
        flag2=1
        break;
      }
    }
    if(flag2===0){
      const err = `unknown model "${sensor.model}"`;
      throw [ new AppError('X_ID', err) ];
    }
    
    //console.log(sensor);

    //@TODO
  }

  /** Subject to field validation as per validate('addSensorData',
   *  info), add reading given by info for sensor specified by
   *  info.sensorId to this. Note that info.sensorId must specify the
   *  id of an existing sensor.  Replace any earlier reading having
   *  the same timestamp for the same sensor.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async addSensorData(info) {
    let sensorData = validate('addSensorData', info);
    let flag3=0;
    let retT;
    let retS;
    let ret = await this.db.collection("sensor").find().toArray();
    for(let i of ret){
      if(i.id === sensorData.sensorId){

        retT = await this.db.collection("sensorType").
        find().toArray();

        retS = await this.db.collection("sensor").
        find().toArray();

        sensorData = await calculateStatus(sensorData,retT,retS);

        await this.db.collection("sensorData").insertOne(sensorData);
        // await this.db.collection("sensorData").replaceOne({timestamp : sensorData.timestamp},
        //   sensorData,{upsert: true});
        //console.log(i.id);
        flag3=1;
        break;
      }
    }
    if(flag3===0){
      const err =  `unknown sensorId "${sensorData.sensorId}"`;
      throw [ new AppError('X_ID', err) ];
    }
    //@TODO
  }

  /** Subject to validation of search-parameters in info as per
   *  validate('findSensorTypes', info), return all sensor-types which
   *  satisfy search specifications in info.  Note that the
   *  search-specs can filter the results by any of the primitive
   *  properties of sensor types (except for meta-properties starting
   *  with '_').
   *
   *  The returned value should be an object containing a data
   *  property which is a list of sensor-types previously added using
   *  addSensorType().  The list should be sorted in ascending order
   *  by id.
   *
   *  The returned object will contain a lastIndex property.  If its
   *  value is non-negative, then that value can be specified as the
   *  _index meta-property for the next search.  Note that the _index
   *  (when set to the lastIndex) and _count search-spec
   *  meta-parameters can be used in successive calls to allow
   *  scrolling through the collection of all sensor-types which meet
   *  some filter criteria.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async findSensorTypes(info) {
    //@TODO
    const searchSpecs = validate('findSensorTypes', info);
   // console.log(searchSpecs);
    

    // if(searchSpecs.id){
    //   console.log("insidee if")
    //   const val = this.COL[searchSpecs.id];
    //   console.log(val);
    //   if(val) data.push(val);
    // }
    let ret;
    let data=[];
    let indexL = -1;
    if(searchSpecs._index!==0 && searchSpecs._count !== 5){
      indexL = searchSpecs._index + searchSpecs._count;
      //console.log(indexL);
    }
    if(searchSpecs.id || searchSpecs.manufacturer || searchSpecs.quantity){
            if(searchSpecs.id){
              //console.log(searchSpecs.id);
              ret = await this.db.collection("sensorType").find({"id" : searchSpecs.id})
              .skip(searchSpecs._index).limit(searchSpecs._count).toArray();
              //data.push(ret);
            }
            else if(searchSpecs.manufacturer && searchSpecs.quantity){
              ret = await this.db.collection("sensorType").
              find({"manufacturer" : searchSpecs.manufacturer,
              "quantity" : searchSpecs.quantity}).sort({"id": 1}).skip(searchSpecs._index)
              .limit(searchSpecs._count).toArray();

             // data.push(ret);
            }
            else{}
            
            if(searchSpecs.manufacturer && !searchSpecs.quantity){
              ret = await this.db.collection("sensorType").find({"manufacturer" : searchSpecs.manufacturer})
              .sort({"id": 1}).skip(searchSpecs._index).limit(searchSpecs._count).toArray();
              //data.push(ret);
            }
            if(searchSpecs.quantity && !searchSpecs.manufacturer){
              ret = await this.db.collection("sensorType").find({"quantity" : searchSpecs.quantity})
              .sort({"id": 1}).skip(searchSpecs._index).limit(searchSpecs._count).toArray();
              //data.push(ret);
            }
    }
    else{
            ret = await this.db.collection("sensorType").find().sort({"id": 1}).skip(searchSpecs._index)
            .limit(searchSpecs._count).toArray();
            //data.push(ret);
    }

    for(let i=0;i<ret.length;i++){
      delete ret[i]['_id'];
    }

    return { data:ret , nextIndex: indexL };
  }
  
  /** Subject to validation of search-parameters in info as per
   *  validate('findSensors', info), return all sensors which satisfy
   *  search specifications in info.  Note that the search-specs can
   *  filter the results by any of the primitive properties of a
   *  sensor (except for meta-properties starting with '_').
   *
   *  The returned value should be an object containing a data
   *  property which is a list of all sensors satisfying the
   *  search-spec which were previously added using addSensor().  The
   *  list should be sorted in ascending order by id.
   *
   *  If info specifies a truthy value for a _doDetail meta-property,
   *  then each sensor S returned within the data array will have an
   *  additional S.sensorType property giving the complete sensor-type
   *  for that sensor S.
   *
   *  The returned object will contain a lastIndex property.  If its
   *  value is non-negative, then that value can be specified as the
   *  _index meta-property for the next search.  Note that the _index (when 
   *  set to the lastIndex) and _count search-spec meta-parameters can be used
   *  in successive calls to allow scrolling through the collection of
   *  all sensors which meet some filter criteria.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async findSensors(info) {
    //@TODO
    const searchSpecs = validate('findSensors', info);
    let ret;
    let data=[];
    let len=-1;
    

    if(searchSpecs.model){
      ret = await this.db.collection("sensor").
              find({"model" : searchSpecs.model}).sort({"id":1})
              .skip(searchSpecs._index).limit(searchSpecs._count).toArray();
      if(ret.length !== 0){
        len = ret.length + searchSpecs._index;
      }
      
      
              //data.push(ret);
    }

    for(let i=0;i<ret.length;i++){
      delete ret[i]['_id'];
    }
    return { data:ret, nextIndex: len };
  }
  
  /** Subject to validation of search-parameters in info as per
   *  validate('findSensorData', info), return all sensor readings
   *  which satisfy search specifications in info.  Note that info
   *  must specify a sensorId property giving the id of a previously
   *  added sensor whose readings are desired.  The search-specs can
   *  filter the results by specifying one or more statuses (separated
   *  by |).
   *
   *  The returned value should be an object containing a data
   *  property which is a list of objects giving readings for the
   *  sensor satisfying the search-specs.  Each object within data
   *  should contain the following properties:
   * 
   *     timestamp: an integer giving the timestamp of the reading.
   *     value: a number giving the value of the reading.
   *     status: one of "ok", "error" or "outOfRange".
   *
   *  The data objects should be sorted in reverse chronological
   *  order by timestamp (latest reading first).
   *
   *  If the search-specs specify a timestamp property with value T,
   *  then the first returned reading should be the latest one having
   *  timestamp <= T.
   * 
   *  If info specifies a truthy value for a doDetail property, 
   *  then the returned object will have additional 
   *  an additional sensorType giving the sensor-type information
   *  for the sensor and a sensor property giving the sensor
   *  information for the sensor.
   *
   *  Note that the timestamp search-spec parameter and _count
   *  search-spec meta-parameters can be used in successive calls to
   *  allow scrolling through the collection of all readings for the
   *  specified sensor.
   *
   *  All user errors must be thrown as an array of AppError's.
   */
  async findSensorData(info) {
    //@TODO
    
    const searchSpecs = validate('findSensorData', info);
    // console.log(searchSpecs);
    // console.log(searchSpecs.statuses);

    /////Find logic//////
    /////////////////////

    
    let statusSD;
    let statusSD2;
    let statusSD3;
    let statusSD4;
    let ret;
    let retSen;
    let retType;
     


    if(searchSpecs.statuses){
      statusSD = searchSpecs.statuses.values();
      statusSD2 = statusSD.next().value;  
      statusSD3 = statusSD.next().value;
      statusSD4 = statusSD.next().value;
    }
    let flagS=0;
    // console.log(statusSD2);  
    // console.log(statusSD3);
    // console.log(statusSD4);

    
    if(searchSpecs.sensorId && statusSD2 && !statusSD3){
      //console.log("hello");
      ret = await this.db.collection("sensorData").find({"sensorId" : searchSpecs.sensorId , "status" : statusSD2 ,
      timestamp: { $lte: searchSpecs.timestamp}})
              .sort({"sensorId": -1})
              .limit(searchSpecs._count).toArray();
      //console.log(ret.length);
      if(ret.length===0)
        flagS=1;
    }
    else if(searchSpecs.sensorId && statusSD2 && statusSD3 && !statusSD4){
      //console.log("hello");
      ret = await this.db.collection("sensorData").find({"sensorId" : searchSpecs.sensorId , 
       $or : [{"status" : statusSD2}, {"status" : statusSD3}] ,
      timestamp: { $lte: searchSpecs.timestamp}})
              .sort({"sensorId": -1}).limit(searchSpecs._count).toArray();
      if(ret.length===0)
        flagS=1;
    }
    else if(searchSpecs.sensorId && statusSD2 && statusSD3 && statusSD4){
      //console.log("hello");
      ret = await this.db.collection("sensorData").find({"sensorId" : searchSpecs.sensorId , 
      $or : [{"status" : statusSD2}, {"status" : statusSD3}, {"status" : statusSD4}] ,
      timestamp: { $lte: searchSpecs.timestamp}})
                .sort({"sensorId": -1}).limit(searchSpecs._count).toArray();
      if(ret.length===0)
        flagS=1;
    }
    if(flagS===1){
      const err = `no id ${searchSpecs.id} sensorData`;
      throw [new AppError('X_ID',err)];
      //console.log("hello");
    }
    

    if(searchSpecs._doDetail){
      let retS = await this.db.collection("sensor").find().toArray();
      let retT = await this.db.collection("sensorType").find().toArray();
      //console.log("HH");
      for(let j of retS){
        //console.log(j);
        if(j.id === searchSpecs.sensorId){
          retSen=j;
        }
      }
      for(let j of retT){
        //console.log(j);
        if(j.id === retSen.model){
          retType=j;
        }
      }

    }
    

    let arrayFinal =[];
    for(let i=0;i<ret.length;i++){
      const picked = (({ timestamp, value, status }) => ({ timestamp, value, status }))(ret[i]);
      arrayFinal.push(picked);
    }

  

    return { data : arrayFinal ,sensorType:retType,sensor:retSen};
  }

  
  
} //class Sensors

function calculateStatus(j,arrayT,arrayS){
    let expectedSD;
    let modelSD;
    let limitSD;

    
      for(let i=0;i<arrayS.length;i++){
        if(j.sensorId === arrayS[i].id){
          expectedSD = arrayS[i].expected;
          modelSD = arrayS[i].model;
        }
      }
      for(let i=0;i<arrayT.length;i++){
        if(modelSD === arrayT[i].id){
          limitSD = arrayT[i].limits;
        }
      }

      // console.log(expectedSD);
      // console.log(limitSD);
      if(parseFloat(j.value)>=parseFloat(expectedSD.min) && parseFloat(j.value)<=parseFloat(expectedSD.max)){
        j.status ='ok';
      }
      else if((parseFloat(j.value)>parseFloat(expectedSD.max) && parseFloat(j.value)<=parseFloat(limitSD.max)) || (parseFloat(j.value)<parseFloat(expectedSD.min) && parseFloat(j.value)>=parseFloat(limitSD.min))){
        j.status ='outOfRange';
      }
      else{
        j.status ='error';
      }
    
  return j;
}

module.exports = Sensors.newSensors;

//Options for creating a mongo client
const MONGO_OPTIONS = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};


function inRange(value, range) {
  return Number(range.min) <= value && value <= Number(range.max);
}

const COLLECTIONS = {
  sensorTypes: 'sensorTypes',
  sensors: 'sensors',
  sensorData: 'sensorData',
};

const DEFAULT_COUNT=5;