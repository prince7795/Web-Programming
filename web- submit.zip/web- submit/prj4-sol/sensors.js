'use strict';

const assert = require('assert');
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const querystring = require('querystring');
//const sensorsWs = require('./sensors-ws')

const Mustache = require('mustache');
const widgetView = require('./widget-view');

const STATIC_DIR = 'statics';
const TEMPLATES_DIR = 'templates';

function serve(port, model, base="") {
  const app = express();
  app.locals.port = port;
  app.locals.base = base;
  app.locals.model = model;
  process.chdir(__dirname);
  app.use(base, express.static(STATIC_DIR));
  setupTemplates(app);
  setupRoutes(app);
  app.listen(port, function() {
    console.log(`listening on port ${port}`);
  });
  //@TODO
}


module.exports = serve;

function setupRoutes(app) {
  const base = app.locals.base;
  /************************ addSensorType  **************************/
  app.get(`${base}/tst-sensor-types-add.html`, addSensorTypes(app)); 
  app.post(`${base}/tst-sensor-types-add.html`, bodyParser.urlencoded({extended: false}),
      postSensorTypes(app));
 
  /************************ searchSensorType  **************************/
  app.get(`${base}/tst-sensor-types-search.html`, doSearch(app));

  /************************ addSensor  **************************/
  app.get(`${base}/tst-sensors-add.html`, addSensor(app)); 
  app.post(`${base}/tst-sensors-add.html`, bodyParser.urlencoded({extended: false}),
      postSensor(app));

  /************************ searchSensor **************************/
  app.get(`${base}/tst-sensors-search.html`, doSearchSensor(app));

}


/************************** Field Definitions **************************/


const FIELDS_INFO = {
  id:{
    friendlyName: 'Sensor Type Id',
    isType: true,
    isSearch: true,
    isText: true,
    isId: true,
    isRequired: true,
    regex: /^[0-9a-zA-Z-_]*$/,
    error: 'User Id field can only contain alphanumerics or _',
  },
  manufacturer:{
    isType: true,
    friendlyName: 'Manufacturer',
    isRequired: true,
    isText: true,
    regex: /^[a-zA-Z- ']*$/,
    error: 'Can contain only -, space or alphabetic characters.',
    isSearch: true,
  },
  modelNumber:{
    friendlyName: 'ModelNumber',
    isType: true,
    isRequired: true,
    isText: true,
    regex: /^\w+$/,
    error: 'Can contain only -, space or alphabetic characters.',
    isSearch: true,
  },
  quantity:{
    friendlyName: 'Measure',
    isType: true,
    isRequired: true,
    isSelect: true,
    // error: 'User Id field can only contain alphanumerics or _',
    isSearch: true,
  },
  minimum:{
    friendlyName: 'Limit-Min',
    isType: true,
    isText: true,
    regex: /^[0-9]*$/,
    error: 'Should be a number',
    isRequired: true,
  },
  maximum:{
    friendlyName: 'Limit-Max',
    isType: true,
    isText: true,
    regex: /^[0-9]*$/,
    error: 'Should be a number',
    isRequired: true,
  },
  _index:{
    friendlyName: 'i',
    isIndex: true,
  },



  /*id:{
    friendlyName: 'sensor ID',
    isSensor: true,
    isSearch: true,
    isText: true,
    isId: true,
    isRequired: true,
    regex: /^\w+$/,
    error: 'User Id field can only contain alphanumerics or _',
  },
  model:{
    friendlyName: 'Model',
    isSensor: true,
    isRequired: true,
    isText: true,
    regex: /^\w+$/,
    error: 'User Id field can only contain alphanumerics or _',
    isSearch: true,
  },
  period:{
    friendlyName: 'Period',
    isSensor: true,
    isRequired: true,
    isText: true,
    regex: /^\w+$/,
    error: 'User Id field can only contain alphanumerics or _',
    isSearch: true,
  },
  minimum2:{
    friendlyName: 'minimum',
    isSensor: true,
    isText: true,
    regex: /^\w+$/,
    error: 'User Id field can only contain alphanumerics or _',
  },
  maximum2:{
    friendlyName: 'maximum',
    isSensor: true,
    isText: true,
    regex: /^\w+$/,
    error: 'User Id field can only contain alphanumerics or _',
  },*/
};

const FIELDS =
  Object.keys(FIELDS_INFO).map((n) => Object.assign({name: n}, FIELDS_INFO[n]));







  const FIELDS_INFO2 = {
    id:{
      friendlyName: 'sensor ID',
      isSearch: true,
      isText: true,
      isId: true,
      isRequired: true,
      regex: /^[0-9a-zA-Z-_]*$/,
      error: 'User Id field can only contain alphanumerics or _',
    },
    model:{
      friendlyName: 'Model',
      isRequired: true,
      isText: true,
      regex: /^[0-9a-zA-Z-_]*$/,
      error: 'User Id field can only contain alphanumerics or _',
      isSearch: true,
    },
    period:{
      friendlyName: 'Period',
      isRequired: true,
      isText: true,
      regex: /^[0-9]*$/,
      error: 'Should be a integer',
      isSearch: true,
    },
    minimum:{
      friendlyName: 'Expected-Min',
      isText: true,
      regex: /^[0-9]*$/,
      error: 'Should be a number',
      isRequired: true,
    },
    maximum:{
      friendlyName: 'Expected-Max',
      isText: true,
      regex: /^[0-9]*$/,
      error: 'Should be a number',
      isRequired: true,
    },
    _index:{
      friendlyName: 'i',
      isIndex: true,
    },
  };
  
  const FIELDS2 =
    Object.keys(FIELDS_INFO2).map((n) => Object.assign({name: n}, FIELDS_INFO2[n]));









//********************************  add Sensor Type  ********************************* */
///////////////////////////////////////////////////////////////////////////////////////

function addSensorTypes(app) {
  return async function(req, res) {
    const model = { base: app.locals.base, fields: FIELDS };
    const html = doMustache(app, 'tst-sensor-types-add', model);
    res.send(html);
  };
};




function postSensorTypes(app) {
  return async function(req, res) {
    const user = getNonEmptyValues(req.body);
    //console.log(user);
    let errors = validate(user, ['id','manufacturer','modelNumber','minimum','maximum']);
    let errors2 = validateMin(user, 'minimum','maximum');
    //console.log(errors);
    //console.log(errors2);
    user.unit="gpm";
    const min = user.minimum;
    const max = user.maximum;
    user.limits={min,max};
    //console.log(user);
    //const isUpdate = req.body.submit === 'tst-sensor-types-add';
    if (!errors && !errors2) {
      try {

        //console.log("try");
        await app.locals.model.update('sensor-types' , user);
        //console.log(user.id);
        res.redirect(`${app.locals.base}/tst-sensor-types-search.html?id=${user.id}`);
        //console.log("try");
      }
      catch (err) {
       // console.log("Min");
	console.error(err);
  errors = wsErrors(err);
  //console.log("catch");
      }
    }
    if (errors || errors2) {
      let html;
      if(errors){
        const model = errorModel(app, user, errors);
        html = doMustache(app,'tst-sensor-types-add', model);
      }
      else if(errors2) {
        const model = errorModel(app, user, errors2);
        html = doMustache(app,'tst-sensor-types-add', model);
      }
      res.send(html);
      //console.log("Hello");
    }
  };
};



//********************************  add Sensor  ********************************* */
///////////////////////////////////////////////////////////////////////////////////////

function addSensor(app) {
  return async function(req, res) {
    const model = { base: app.locals.base, fieldsSensor: FIELDS2 };
    const html = doMustache(app, 'tst-sensor-add', model);
    res.send(html);
  };
};




function postSensor(app) {
  return async function(req, res) {
    const user = getNonEmptyValues2(req.body);
    //console.log(user);

    let errors = validate2(user, ['id','model','period','minimum','maximum']);
    let errors2 = validateMin2(user, 'minimum','maximum');
    //console.log(errors);
    //console.log(errors2);
    //user.unit="gpm";
    let min = user.minimum;
    let max = user.maximum;
    //console.log(min);
    //console.log(max);
    user.expected={min,max};
    //user.id = user.id1;
    //console.log(user);
    //const isUpdate = req.body.submit === 'tst-sensor-types-add';
    if (!errors && !errors2 ) {
      try {

        //console.log("try");
        await app.locals.model.update('sensors' , user);
        //console.log("try2");
        res.redirect(`${app.locals.base}/tst-sensors-search.html?id=${user.id}`);
        //console.log("try3");
      }
      catch (err) {
	console.error(err);
  errors = wsErrors(err);
    //console.log("catch");
      }
    }
    if (errors || errors2) {
      let html;
      if(errors){
        const model = errorModel2(app, user, errors);
        html = doMustache(app,'tst-sensor-add', model);
      }
      else if(errors2) {
        const model = errorModel2(app, user, errors2);
        html = doMustache(app,'tst-sensor-add', model);
      }
      res.send(html);
      //console.log("Hello");
    }
  };
};


//////////******************************Search Sensor Types********************************* */

function doSearch(app) {
  return async function(req, res) {
    const isSubmit = req.query.submit !== undefined;
    let usersTemp = [];
    let users = [];
    let errors = undefined;
    const search = getNonEmptyValues(req.query);
    // console.log("search");
    // console.log(search);
    
    //console.log(search);
    //if (isSubmit) {
      errors = validate(search);
  //     if (Object.keys(search).length == 0) {
	// const msg = 'at least one search parameter must be specified';
	// errors = Object.assign(errors || {}, { _: msg });
  //     }
     // if (!errors) {
  // const q = querystring.stringify(search);
  // console.log("q");
  // console.log(q);
  // const [q2,q3,q4,q5] = q.split("&");
  // console.log(q2);
  // console.log(q3);
  // console.log(q4);
  // console.log(q5);
  // const query2 = q2.split("=");
  // console.log(query2[0]);
  // console.log(query2[1]);
  // const x1 = "'" + query2[0] + "'";
  // const x2 = "'" + query2[1] + "'";
  // const y1 = "'" + x1 + "':'" + x2 + "'";

  // console.log(x1);
  // console.log(x2);
  //const fq2 = { query2[0] , query2[1]};
	try {
    users = await app.locals.model.list('sensor-types',search);
    // console.log(users);
    //search._index=users.nextIndex;
   // search._previous=users.nextIndex;
    //usersTemp = await app.locals.model.list('sensor-types',search);
    // console.log("''''''''''''''''''''''''''''");
    // console.log(usersTemp);
    //users.push(user1);
    for(var i of users.data){
      i.minimum = i.limits.min;
      i.maximum = i.limits.max;
    }
    var nIndex;
    var pIndex;
    
    if(users.nextIndex > 0){
      //console.log(users.nextIndex);
      nIndex = users.nextIndex;
    }

    if(users.nextIndex > 5){
      if(users.previousIndex === 0){
        pIndex = JSON.stringify(users.previousIndex);
      }
      else
        pIndex = users.previousIndex;
    }

    // console.log(users.data[0].minimum);
    // console.log(users.data[0].limits);
    // users.data[1].minimum = users.data[1].limits.min;
    // console.log(users.data[1].minimum);
    // console.log(users.data[1].limits.min);
	}
	catch (err) {
          console.error(err);
	  errors = wsErrors(err);
	}
	// if (users.length === 0) {
	//   errors = {_: 'no users found for specified criteria; please retry'};
	// }
     // }
    //}
    let model, template =  'tst-sensor-types-search';

    if(errors){
      model = { base: app.locals.base, errorDisp: errors, fields2: FIELDS}
    }
    else{
    
      const fields =
	    users.data.map((u) => ({id: u.id, fields: fieldsWithValues(u)}));
      model = { base: app.locals.base, users: fields , fields2: FIELDS, pInd:pIndex, nInd:nIndex };
    
    }
     
    const html = doMustache(app, template, model);
    res.send(html);
  };
};








//////////******************************Search Sensor ********************************* */

function doSearchSensor(app) {
  return async function(req, res) {
    const isSubmit = req.query.submit !== undefined;
    let users = [];
    let errors = undefined;
    const search = getNonEmptyValues2(req.query);
    // console.log("search");
    // console.log(search);
    //if (isSubmit) {
      errors = validate2(search);
  //     if (Object.keys(search).length == 0) {
	// const msg = 'at least one search parameter must be specified';
	// errors = Object.assign(errors || {}, { _: msg });
  //     }
      // console.log("1");
      // console.log(errors);
     // if (!errors) {
  // const q = querystring.stringify(search);
  // console.log("q");
  // console.log(q);
  // const [q2,q3,q4,q5] = q.split("&");
  // console.log(q2);
  // console.log(q3);
  // console.log(q4);
  // console.log(q5);
  // const query2 = q2.split("=");
  // console.log(query2[0]);
  // console.log(query2[1]);
  // const x1 = "'" + query2[0] + "'";
  // const x2 = "'" + query2[1] + "'";
  // const y1 = "'" + x1 + "':'" + x2 + "'";

  // console.log(x1);
  // console.log(x2);
  //const fq2 = { query2[0] , query2[1]};
	try {
    users = await app.locals.model.list('sensors',search);
    //console.log(user1);
    //users.push(user1);
    for(var i of users.data){
      i.minimum = i.expected.min;
      i.maximum = i.expected.max;
    }

    var nIndex1;
    var pIndex1;
    if(users.nextIndex > 0){
      //console.log(users.nextIndex);
      nIndex1 = users.nextIndex;
    }

    if(users.nextIndex > 5){
      //console.log(users.previousIndex);
      if(users.previousIndex === 0){
        pIndex1 = JSON.stringify(users.previousIndex);
      }
      else
        pIndex1 = users.previousIndex;
    }

	}
	catch (err) {
          console.error(err);
    errors = wsErrors(err);
    // console.log(errors);
	}
	// if (users.data.length === 0) {
	//   errors = {_: 'no users found for specified criteria; please retry'};
  // }
  // console.log("2");
  // console.log(errors);
     // }
    //}
    let model, template =  'tst-sensor-search';
    if(errors){
      model = { base: app.locals.base, errorDisp: errors, fields2: FIELDS2}
    }
    else{

    
      const fields =
  users.data.map((u) => ({id: u.id, fields: fieldsWithValues2(u)}));
  console
      model = { base: app.locals.base, users: fields , fields2: FIELDS2 , pInd1:pIndex1, nInd1:nIndex1 };
    }
    
      
     
    const html = doMustache(app, template, model);
    res.send(html);
  };
};








/************************** Field Utilities ****************************/

/************************** Field Utilities ****************************/

/** Return copy of FIELDS with values and errors injected into it. */
function fieldsWithValues(values, errors={}) {
  return FIELDS.map(function (info) {
    const name = info.name;
    const extraInfo = { value: values[name] };
    //console.log(extraInfo.value);
    if(extraInfo.value === 0){
      extraInfo.value = JSON.stringify(extraInfo.value)
      //console.log("Here");
    }
    if (errors[name]) extraInfo.errorMessage = errors[name];
    return Object.assign(extraInfo, info);
  });
}


/** Return copy of FIELDS with values and errors injected into it. */
function fieldsWithValues2(values, errors={}) {
  return FIELDS2.map(function (info) {
    const name = info.name;
    const extraInfo = { value: values[name] };
    if(extraInfo.value === 0){
      extraInfo.value = JSON.stringify(extraInfo.value)
      //console.log("Here");
    }
   // console.log(extraInfo.value);
    if (errors[name]) extraInfo.errorMessage = errors[name];
    return Object.assign(extraInfo, info);
  });
}



/** Given map of field values and requires containing list of required
 *  fields, validate values.  Return errors hash or falsy if no errors.
 */
function validate(values, requires=[]) {
  const errors = {};
  requires.forEach(function (name) {
    if (values[name] === undefined) {
      errors[name] =
	`A value for '${FIELDS_INFO[name].friendlyName}' must be provided`;
    }
  });
  for (const name of Object.keys(values)) {
    const fieldInfo = FIELDS_INFO[name];
    const value = values[name];
    if (fieldInfo.regex && !value.match(fieldInfo.regex)) {
      errors[name] = fieldInfo.error;
    }
  }
  return Object.keys(errors).length > 0 && errors;
}


function validateMin(values, a,b) {
  const errors = {};
  
    if (values[a] > values[b]) {
      errors[a] =
	`Minimum value should not be greater than Maximum value`;
    }
    else{
      errors[a]=1;
    }

    //console.log("Min");
  
  if(errors[a] === 1)
    return false;
  else
    return errors;
}



function validate2(values, requires=[]) {
  const errors = {};
  requires.forEach(function (name) {
    if (values[name] === undefined) {
      errors[name] =
	`A value for '${FIELDS_INFO2[name].friendlyName}' must be provided`;
    }
  });
  for (const name of Object.keys(values)) {
    const fieldInfo = FIELDS_INFO2[name];
    const value = values[name];
    if (fieldInfo.regex && !value.match(fieldInfo.regex)) {
      errors[name] = fieldInfo.error;
    }
  }
  return Object.keys(errors).length > 0 && errors;
}



function validateMin2(values, a,b) {
  const errors = {};
  
    if (values[a] > values[b]) {
      errors[a] =
	`Minimum value should not be greater than Maximum value`;
    }
    else{
      errors[a]=1;
    }

    //console.log("Min");
  
  if(errors[a] === 1)
    return false;
  else
    return errors;
}




function getNonEmptyValues(values) {
  const out = {};
  Object.keys(values).forEach(function(k) {
    if (FIELDS_INFO[k] !== undefined) {
      const v = values[k];
      if (v && v.trim().length > 0) out[k] = v.trim();
    }
  });
  return out;
}

function getNonEmptyValues2(values) {
  const out = {};
  Object.keys(values).forEach(function(k) {
    if (FIELDS_INFO2[k] !== undefined) {
      const v = values[k];
      if (v && v.trim().length > 0) out[k] = v.trim();
    }
  });
  return out;
}

/** Return a model suitable for mixing into a template */
function errorModel(app, values={}, errors={}) {
  return {
    base: app.locals.base,
    errors: errors._,
    fields: fieldsWithValues(values, errors)
  };
}


/** Return a model suitable for mixing into a template */
function errorModel2(app, values={}, errors={}) {
  return {
    base: app.locals.base,
    errors: errors._,
    fieldsSensor: fieldsWithValues2(values, errors)
  };
}

/************************ General Utilities ****************************/

/** Decode an error thrown by web services into an errors hash
 *  with a _ key.
 */
function wsErrors(err) {
  const msg = (err.message) ? err.message : 'web service error';
  console.error(msg);
  return { _: [ msg ] };
}

function doMustache(app, templateId, view) {
  const templates = { footer: app.templates.footer };
  return Mustache.render(app.templates[templateId], view, templates);
}

function errorPage(app, errors, res) {
  if (!Array.isArray(errors)) errors = [ errors ];
  const html = doMustache(app, 'errors', { errors: errors });
  res.send(html);
}

function isNonEmpty(v) {
  return (v !== undefined) && v.trim().length > 0;
}

function setupTemplates(app) {
  app.templates = {};
  for (let fname of fs.readdirSync(TEMPLATES_DIR)) {
    const m = fname.match(/^([\w\-]+)\.ms$/);
    if (!m) continue;
    try {
      app.templates[m[1]] =
	String(fs.readFileSync(`${TEMPLATES_DIR}/${fname}`));
    }
    catch (e) {
      console.error(`cannot read ${fname}: ${e}`);
      process.exit(1);
    }
  }
}
//@TODO
